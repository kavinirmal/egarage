package com.egaragesystem.egarage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EgarageApplicationTests {

	@Test
	void contextLoads() {
	}

}
