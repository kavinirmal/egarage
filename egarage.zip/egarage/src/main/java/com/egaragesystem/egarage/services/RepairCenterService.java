package com.egaragesystem.egarage.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.egaragesystem.egarage.models.RepairCenter;
import com.egaragesystem.egarage.repositories.RepairCenterRepository;

@Service
public class RepairCenterService {
	
	@Autowired
	private RepairCenterRepository repairCenterRepository;

	public List<RepairCenter> getRepairCenters(){
		return repairCenterRepository.findAll();
	}
	
	public void save(RepairCenter repairCenter) {
		repairCenterRepository.save(repairCenter);
	}

}
