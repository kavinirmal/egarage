package com.egaragesystem.egarage.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import com.egaragesystem.egarage.models.SparePart;
import com.egaragesystem.egarage.services.SparePartService;

@Controller
public class SparePartController {

	@Autowired
	private SparePartService sparePart;
	
	@GetMapping("/spareParts")
	public String getSpareParts(Model model) {
		
		List<SparePart> sparePartList = sparePart.getSpareParts();
		
		model.addAttribute("spareParts", sparePartList);
		
		return "spare-part";
	}
	
	@PostMapping("/spareParts/addNew")
	public String addNew(SparePart spareParts) {
		
		sparePart.save(spareParts);
		
		return "redirect:/spareParts";
		
	}
}
