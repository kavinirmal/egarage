package com.egaragesystem.egarage.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egaragesystem.egarage.models.MobileService;
import com.egaragesystem.egarage.repositories.MobileServiceRepository;

@Service
public class MobileSreviceService {
	
	@Autowired
	private MobileServiceRepository mobileServiceRepository;

	public List<MobileService> getMobileSevices(){
		return mobileServiceRepository.findAll();
	}
	
	public void save(MobileService mobileService) {
		mobileServiceRepository.save(mobileService);
	}
	
	public Optional<MobileService> findById(int id) {
		return mobileServiceRepository.findById(id);
	}	
	
	public void delete(int id) {
		mobileServiceRepository.deleteById(id);
	}
	
	public void update( MobileService mobileService) {
		mobileServiceRepository.save(mobileService);
	}


}
