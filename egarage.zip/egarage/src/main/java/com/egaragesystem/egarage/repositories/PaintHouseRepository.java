package com.egaragesystem.egarage.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.egaragesystem.egarage.models.PaintHouse;


@Repository
public interface PaintHouseRepository extends JpaRepository<PaintHouse, Integer> {

}
