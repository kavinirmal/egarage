package com.egaragesystem.egarage.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.egaragesystem.egarage.models.PaintHouse;
import com.egaragesystem.egarage.services.PaintHouseService;
@Controller
public class PaintHouseController {
	
	@Autowired
	private PaintHouseService paintHouseService;

	@GetMapping("/paintHouses")
	public String getPaintHouses(Model model) {
		 
		List<PaintHouse> paintHouseList = paintHouseService.getPaintHouses();
		model.addAttribute("paintHouses", paintHouseList);
		return "paint-house";
	}
	@PostMapping("/paintHouses/addNew")
	public String addNew(PaintHouse paintHouses) {
		
		paintHouseService.save(paintHouses);
		return "redirect:/paintHouses";
		
	}
}
