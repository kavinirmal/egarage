package com.egaragesystem.egarage.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egaragesystem.egarage.models.RentACar;
import com.egaragesystem.egarage.repositories.RentACarRepository;

@Service
public class RentACarService {
	@Autowired
	private RentACarRepository rentACarRepository;

	public List<RentACar> getRentACars(){
		return rentACarRepository.findAll();
	}
	
	public void save(RentACar rentCar) {
		rentACarRepository.save(rentCar);
	}

}
