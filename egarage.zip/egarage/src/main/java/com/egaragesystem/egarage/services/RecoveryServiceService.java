package com.egaragesystem.egarage.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.egaragesystem.egarage.models.RecoveryService;
import com.egaragesystem.egarage.repositories.RecoveryServiceRepository;

@Service
public class RecoveryServiceService {
	
	@Autowired
	private RecoveryServiceRepository recoveryServiceRepository;

	public List<RecoveryService> getRecoveryService(){
		return recoveryServiceRepository.findAll();
	}
	
	public void save(RecoveryService recoveryService) {
		recoveryServiceRepository.save(recoveryService);
	}

}
