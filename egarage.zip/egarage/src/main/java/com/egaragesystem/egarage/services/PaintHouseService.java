package com.egaragesystem.egarage.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egaragesystem.egarage.models.PaintHouse;
import com.egaragesystem.egarage.repositories.PaintHouseRepository;

@Service
public class PaintHouseService {
	
	@Autowired
	private PaintHouseRepository paintHouseRepository;

	public List<PaintHouse> getPaintHouses(){
		return paintHouseRepository.findAll();
	}
	
	public void save(PaintHouse paintHouse) {
		paintHouseRepository.save(paintHouse);
	}

}
