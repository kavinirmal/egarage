package com.egaragesystem.egarage.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.egaragesystem.egarage.models.RecoveryService;

@Repository
public interface RecoveryServiceRepository extends JpaRepository<RecoveryService, Integer> {

}
