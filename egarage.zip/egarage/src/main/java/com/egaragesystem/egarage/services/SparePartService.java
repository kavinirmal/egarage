package com.egaragesystem.egarage.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.egaragesystem.egarage.models.SparePart;
import com.egaragesystem.egarage.repositories.SparePartRepository;

@Service
public class SparePartService {
	
	@Autowired
	private SparePartRepository sparePartRepository;

	public List<SparePart> getSpareParts(){
		return sparePartRepository.findAll();
	}
	
	public void save(SparePart sparePart) {
		sparePartRepository.save(sparePart);
	}

}
