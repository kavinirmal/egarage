package com.egaragesystem.egarage.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import com.egaragesystem.egarage.models.TyreHouse;
import com.egaragesystem.egarage.services.TyreHouseService;

@Controller
public class TyreHouseController {
	
	@Autowired
	private TyreHouseService tyreHouse;
	
	@GetMapping("/tyreHouses")
	public String getTyreHouses(Model model) {
		
		List<TyreHouse> tyreHousesList = tyreHouse.getTyreHouses();
		
		model.addAttribute("tyreHouses", tyreHousesList);
		
		return "tyre-house";
	}
	
	@PostMapping("/tyreHouses/addNew")
	public String addNew(TyreHouse tyreHouses) {
		
		tyreHouse.save(tyreHouses);
		
		return "redirect:/tyreHouses";
		
	}

}
