package com.egaragesystem.egarage.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egaragesystem.egarage.models.ServiceCenter;
import com.egaragesystem.egarage.repositories.ServiceCenterRepository;

@Service
public class ServiceCenterService {
	
	@Autowired
	private ServiceCenterRepository serviceCenterRepository;

	public List<ServiceCenter> getServiceCenters(){
		return serviceCenterRepository.findAll();
	}
	
	public void save(ServiceCenter serviceCenter) {
		serviceCenterRepository.save(serviceCenter);
	}

}
