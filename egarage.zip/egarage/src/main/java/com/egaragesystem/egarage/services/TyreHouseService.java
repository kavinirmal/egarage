package com.egaragesystem.egarage.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.egaragesystem.egarage.models.TyreHouse;
import com.egaragesystem.egarage.repositories.TyreHouseRepository;

@Service
public class TyreHouseService {
	
	@Autowired
	private TyreHouseRepository tyreHouseRepository;

	public List<TyreHouse> getTyreHouses(){
		return tyreHouseRepository.findAll();
	}
	
	public void save(TyreHouse tyreHouse) {
		tyreHouseRepository.save(tyreHouse);
	}

}
