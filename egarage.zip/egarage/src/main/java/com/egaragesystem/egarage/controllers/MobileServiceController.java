package com.egaragesystem.egarage.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.egaragesystem.egarage.models.MobileService;
import com.egaragesystem.egarage.services.MobileSreviceService;
@Controller
public class MobileServiceController {
	
	@Autowired
	private MobileSreviceService mobileService;
	
	@GetMapping("/mobileServices")
	public String getMobileServices(Model model) {
		
		List<MobileService> mobileServiceList = mobileService.getMobileSevices();
		
		model.addAttribute("mobileServices", mobileServiceList);
		
		return "mobile-service";
	}
	
	@PostMapping("/mobileServices/addNew")
	public String addNew(MobileService mobileServices) {
		
		mobileService.save(mobileServices);
		return "redirect:/mobileServices";
		
	}
	
	@RequestMapping("mobileServices/findById") 
	@ResponseBody
	public Optional<MobileService> findById(Integer id)
	{
		return mobileService.findById(id);
	}
	
	@RequestMapping(value="mobileServices/update", method = {RequestMethod.PUT, RequestMethod.GET})
	public String update(MobileService mobileServices) {
		mobileService.save(mobileServices);
		return "redirect:/mobileServices";
	}
	
	/*
	 * @RequestMapping(value="mobileServices/delete", method =
	 * {RequestMethod.DELETE, RequestMethod.GET}) public String delete(Integer id) {
	 * mobileService.delete(id); return "redirect:/mobileServices"; }
	 */
}
