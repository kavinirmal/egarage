package com.egaragesystem.egarage.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import com.egaragesystem.egarage.models.RepairCenter;
import com.egaragesystem.egarage.services.RepairCenterService;

@Controller
public class RepairCenterController {
 
	@Autowired
	private RepairCenterService repairCenter;
	
	@GetMapping("/repairCenters")
	public String getRepairCenters(Model model) {
		
		List<RepairCenter> repairCenterList = repairCenter.getRepairCenters();
		
		model.addAttribute("repairCenters", repairCenterList);
		
		return "repair-center";
	}
	
	@PostMapping("/repairCenters/addNew")
	public String addNew(RepairCenter repairCenters) {
		
		repairCenter.save(repairCenters);
		return "redirect:/repairCenters";
		
	}
}
