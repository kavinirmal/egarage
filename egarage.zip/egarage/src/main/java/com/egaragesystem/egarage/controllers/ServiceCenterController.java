package com.egaragesystem.egarage.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.egaragesystem.egarage.models.ServiceCenter;
import com.egaragesystem.egarage.services.ServiceCenterService;

@Controller
public class ServiceCenterController {
	
	@Autowired
	private ServiceCenterService serviceCenter;
	
	@GetMapping("/serviceCenters")
	public String getTyreHouses(Model model) {
		
		List<ServiceCenter> serviceCentersList = serviceCenter.getServiceCenters();
		
		model.addAttribute("serviceCenters", serviceCentersList);
		
		return "service-center";
	}
	
	@PostMapping("/serviceCenters/addNew")
	public String addNew(ServiceCenter serviceCenters) {
		
		serviceCenter.save(serviceCenters);
		
		return "redirect:/serviceCenters";
		
	}

}
