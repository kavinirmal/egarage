package javax.persistence;

public class Entity {

}
