
$('document').ready(function () {

	$('.table .btn-primary').on('click', function (event) {
		event.preventDefault();
		var href = $(this).attr('href');
		$.get(href, function (mobileService, status) {
			$('#idEdit').val(mobileService.id);
			$('#descriptionEdit').val(mobileService.description);
			$('#nameEdit').val(mobileService.name);
			$('#phoneNumberEdit').val(mobileService.phoneNumber);
			$('#emailEdit').val(mobileService.email);
			$('#addressEdit').val(mobileService.address);
		});
		$('#editModal').modal();
	});



	$('.table #detailsButton').on('click', function (event) {
		event.preventDefault();
		var href = $(this).attr('href');
		$.get(href, function (mobileService, status) {
			$('#idDetails').val(mobileService.id);
			$('#descriptionDetails').val(mobileService.description);
			$('#nameDetails').val(mobileService.name);
			$('#phoneNumberDetails').val(mobileService.phoneNumber);
			$('#emailDetails').val(mobileService.email);
			$('#addressDetails').val(mobileService.address);
			$('#lastModifiedByDetails').val(mobileService.lastModifiedBy);
			$('#lastModifiedDateDetails').val(mobileService.lastModifiedDate.substr(0, 19).replace("T", " "));
		});
		$('#detailsModal').modal();
	});

	$('.table #deleteButton').on('click', function (event) {
		event.preventDefault();
		var href = $(this).attr('href');
		$('#deleteModal #delRef').attr('href', href);
		$('#deleteModal').modal();
	});
});